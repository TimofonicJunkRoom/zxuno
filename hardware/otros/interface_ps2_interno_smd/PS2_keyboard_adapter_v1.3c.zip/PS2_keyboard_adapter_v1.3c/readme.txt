Hi, Ben! :

This is for fixing a design flaw present in the microcontroller used for the PS2 interface.
The flaw is that if an output from the microcontroller is held low while another source pulls it
high, with no current limit resistor in between, the microcontroller might loose flash contents,
behaving incorrectly, or not working at all, even the fail-safe mode.

In our interface, this happens when a RESET condition is fired from the PS/2 keyboard. Port 0.3 is
directly connected from the microcontroller to the RESET input at the ZX rear bus. The firmware pulls
down this output for 16 microseconds, then high (actually, it changes from high impedance mode to
low, then high impedance again).

Inside the ZX Spectrum, a 1uF capacitor holds the Z80 reset input high. When port 0.3 changes to low,
all the charge inside the capacitor flow instantaneosly through this port,  thus, triggering the 
design flaw. The capacitor is connected to +5V by a charging resistor of 220K.

Therefore, it's mandatory to limit the amount of current through the device by means of a resistor
from port 0.3 to the RESET pin at the ZX Bus.

The pictures included in this fix show which track has to be cut (step 1), prepare to soldering 
(step 2) and place a 1K resistor (SMD 0805 in the picture) bridging the gap. This resistor limits the
amount of current so it is not dangerous for the microcontroller to pull port 0.3 down while there is
still charge inside the 1uF capacitor.

For the reset condition to appear at the Z80 reset pin, the capacitor must be complete discharged.
This is acomplished by our 1K resistor, but the discharge process is slower than before, so a low
pulse of 16 microseconds is not enough.

So, the firmware has been updated to generate a pulse of 20 miliseconds, which I find enough to
completely discharge the capacitor, and leave less than 0,7V at the Z80 reset pin. The file updated
is included in this archive (translate_pc_to_zx.asm).

Also, I've included the updated HEX files for spanish and US-english keyboards.

Cheers!

Miguel Angel (mcleod_ideafix)


