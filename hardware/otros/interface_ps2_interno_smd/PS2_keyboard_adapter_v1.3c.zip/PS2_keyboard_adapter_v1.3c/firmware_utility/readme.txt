Firmware update v1.3b readme file
---------------------------------

Changelog from 1.3 to 1.3b
--------------------------
- User program (for turboloading when Ctrl-Alt-F1 is pressed) size expanded to 16K.
- Fixed small bug that mapped the "=" from the PC keyboard to the "+" in the Spectrum.
- Pointers to specific firmware areas added from offset 100h (more about this in 
www.zxprojects.com)
- Source code: one file per keymap instead of three. Some cleanup.


Files
-----
- BIN file: use this as source file to make hacks and modifications to 
the firmware (see article at www.zxprojects.com for details)
- TAP file: this is the autoexecutable update tool, plus the firmware
file. Use this with your favorite mass storage technology to load it
into the Spectrum.
- WAV file: this is the same as the TAP file, but at much higher speed.
This has been possible thanks to the OTLA project 
(http://personal.auna.com/casariche/otla/otla.htm)
- SBB file: this is the same as the TAP file, but intended to be played
with the OTLA Player, so the user can use a different load scheme, if the
WAV file doesn'twork for him.
- HEX file: this is the full firmware, including the fail-safe bootblock
and routines. This can be only used with the Silabs programmer.

Update Procedure
----------------
- Turn off your Spectrum.
- Plug-in the PS/2 adapter.
- Put the jumper cap as shown in your user manual.
- Plug-in a working PS/2 keyboard in your adapter.
- Turn on your Spectrum. Scroll lock should be on, indicating that you
are in fail-safe mode. If not, re-check your jumper settings and repeat
procedure.

In fail-safe mode, the PC keyboard has a 1-to-1 mapping to the Spectrum 
keyboard matrix. Only 40 PC keys are used: alphabetic keys (26), number
(top row) keys (10), space bar (1), return key from alphanumeric block (1),
left shift as CAPS SHIFT (1), and right shift as SYMBOL SHIFT (1). Any
other key is disabled in this mode, so do macros and Sinclair joystick feature.

DON'T PRESS THE ESC KEY UNTIL IT IS REQUIRED TO DO SO.

- If you are going to use a DivIDE or compatible device for loading the
update, use it to select your TAP file. After that, return to BASIC.
- Type LOAD "" (J, then right shift + P twice) and press Return.
- Play your mass storage device to load the update program.
- The update program will pause at step 1 (checking communications), 
waiting for the user to press the ESC key. Press ESC now.
- The remaining steps will be performed automatically. At the end, a message
will inform you that the update has been done.
- Turn off your Spectrum.
- Remove the jumper cap.
- Turn on the Spectrum.

The keyboard should turn NumLock on. If so, everything is fine. If not, turn
off the Spectrum, re-check the connection between the PC keyboard and 
the adapter and turn it on again. If no lights are on, repeat the update
procedure from the beginning.
